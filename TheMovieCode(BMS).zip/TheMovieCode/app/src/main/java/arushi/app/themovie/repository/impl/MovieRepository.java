package arushi.app.themovie.repository.impl;


import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import arushi.app.themovie.api.IMovieApi;
import arushi.app.themovie.baseClass.MyApplication;
import arushi.app.themovie.callback.CustomRetrofitCallback;
import arushi.app.themovie.callback.IAsyncResult;
import arushi.app.themovie.database.dao.IMovieDao;
import arushi.app.themovie.model.CreditModel;
import arushi.app.themovie.model.ListMoviesModel;
import arushi.app.themovie.model.MovieModel;
import arushi.app.themovie.model.ReviewsModel;
import arushi.app.themovie.model.SimilarModel;
import arushi.app.themovie.model.SynopsisModel;
import arushi.app.themovie.repository.BaseRepository;
import arushi.app.themovie.repository.interfaces.IMovieRepository;

import java.util.List;

import javax.annotation.Nullable;

import retrofit2.Response;

public class MovieRepository extends BaseRepository implements IMovieRepository {
    private static final String TAG = MovieRepository.class.getSimpleName();
    private final IMovieApi iApi;
    private IMovieDao movieDao;
    private final String API_KEY = "8a0d5f1507e873f02f5bc1b73c4e0cc3";

    public MovieRepository() {
        MyApplication context = MyApplication.getInstance();
        iApi = MyApplication.getInstance().getRetrofitClient().create(IMovieApi.class);
        movieDao = context.getAppDataBase(context).getIMovieDao();
    }

    @Override
    public void getMovieList(int page, String lang, final IAsyncResult<ListMoviesModel> result) {
        iApi.getMoviesList(API_KEY, lang, page).enqueue(new CustomRetrofitCallback<ListMoviesModel>() {
            @Override
            protected void success(Response<ListMoviesModel> response) {
                if (null != response.body())
//                    saveAllRecordInDB(response.body().getResults(), null);
                result.success(response.body());
            }

            @Override
            protected void fail(Throwable t) {
                Log.e(TAG, t.getLocalizedMessage());
                result.fail(NETWORK_ERROR);

            }
        });
    }

    @Override
    public void saveAllRecordInDB(final List<MovieModel> movieList, @Nullable final IAsyncResult<List<MovieModel>> result) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    long[] longs = movieDao.saveAllMoviesDetails(movieList);
                    if (result != null) {
                        result.success(movieList);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Log.e(TAG, "Local Db, save movie failed");
                    if (result != null) {
                        result.fail(LOCAL_DB_ERROR);
                    }
                }
            }
        }).start();
    }

    @Override
    public void getMovieByID(final int id, final IAsyncResult<MovieModel> result) {
        new Thread(new Runnable() {
            MovieModel model;

            @Override
            public void run() {
                try {
                    model = movieDao.getMovieByID(id);
                } catch (Exception ex) {
                    Log.e(TAG, "Error in getting tracker from local db. Reason- " + ex.toString());
                    model = null;
                } finally {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override
                        public void run() {
                            if (model == null) {
                                result.fail(LOCAL_DB_ERROR);
                            } else {
                                result.success(model);
                            }
                        }
                    });
                }
            }
        }).start();
    }

    @Override
    public void getAllMovie(final IAsyncResult<List<MovieModel>> result) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    List<MovieModel> movieList = movieDao.getAllMovieRecord();
                    if (result != null) {
                        result.success(movieList);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    Log.e(TAG, "Local Db, save movie failed");
                    result.fail(LOCAL_DB_ERROR);
                }
            }
        }).start();
    }

    @Override
    public void getMovieSynopsis(int movieId,String lang, final IAsyncResult<SynopsisModel> result) {
        iApi.getMovieSynopsis(movieId, API_KEY, lang).enqueue(new CustomRetrofitCallback<SynopsisModel>() {
            @Override
            protected void success(Response<SynopsisModel> response) {
                if (null != response.body())
                    result.success(response.body());
            }

            @Override
            protected void fail(Throwable t) {
                Log.e(TAG, t.getLocalizedMessage());
                result.fail(NETWORK_ERROR);

            }
        });
    }

    @Override
    public void getMovieReviews(int movieId,String lang, final IAsyncResult<ReviewsModel> result) {
        iApi.getMovieReviews(movieId, API_KEY, lang, 1).enqueue(new CustomRetrofitCallback<ReviewsModel>() {
            @Override
            protected void success(Response<ReviewsModel> response) {
                if (null != response.body())
                    result.success(response.body());
            }

            @Override
            protected void fail(Throwable t) {
                Log.e(TAG, t.getLocalizedMessage());
                result.fail(NETWORK_ERROR);

            }
        });
    }

    @Override
    public void getMovieCredits(int movieId, final IAsyncResult<CreditModel> result) {
        iApi.getMovieCredit(movieId, API_KEY).enqueue(new CustomRetrofitCallback<CreditModel>() {
            @Override
            protected void success(Response<CreditModel> response) {
                if (null != response.body())
                    result.success(response.body());
            }

            @Override
            protected void fail(Throwable t) {
                Log.e(TAG, t.getLocalizedMessage());
                result.fail(NETWORK_ERROR);

            }
        });
    }

    @Override
    public void getSimilerMoviesList(int movieId,String lang, final IAsyncResult<SimilarModel> result) {
        iApi.getSimilarMovies(movieId, API_KEY, lang, 1).enqueue(new CustomRetrofitCallback<SimilarModel>() {
            @Override
            protected void success(Response<SimilarModel> response) {
                if (null != response.body())
                    result.success(response.body());
            }

            @Override
            protected void fail(Throwable t) {
                Log.e(TAG, t.getLocalizedMessage());
                result.fail(NETWORK_ERROR);

            }
        });
    }
}
