package arushi.app.themovie.baseClass;

import android.app.Application;
import android.content.Context;

import androidx.room.Room;

import arushi.app.themovie.database.AppDataBase;
import arushi.app.themovie.utils.Url;
import com.facebook.stetho.Stetho;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyApplication extends Application {

    private static MyApplication sInstance;
    private Retrofit retrofit;
    private static AppDataBase appDataBase;

    public static MyApplication getInstance() {
        if (null == sInstance) {
            sInstance = new MyApplication();
        }
        return sInstance;
    }

    public Retrofit getRetrofitClient() {
        if (null == retrofit) {
            retrofit = getClient();
        }
        return retrofit;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        getAppDataBase(getInstance());
        Stetho.initializeWithDefaults(this);
    }

    private Retrofit getClient() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .readTimeout(30, TimeUnit.SECONDS)
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS).build();

        retrofit = new Retrofit.Builder()
                .baseUrl(Url.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        return retrofit;
    }

    public AppDataBase getAppDataBase(Context context) {
        if (null == appDataBase) {
            appDataBase = Room.databaseBuilder(this, AppDataBase.class, "the_movie.db").build();
        }
        return appDataBase;
    }
}
