package arushi.app.themovie.repository.interfaces;

import arushi.app.themovie.callback.IAsyncResult;
import arushi.app.themovie.model.CreditModel;
import arushi.app.themovie.model.ListMoviesModel;
import arushi.app.themovie.model.MovieModel;
import arushi.app.themovie.model.ReviewsModel;
import arushi.app.themovie.model.SimilarModel;
import arushi.app.themovie.model.SynopsisModel;

import java.util.List;

public interface IMovieRepository {

    void getMovieList(int page, String lang, IAsyncResult<ListMoviesModel> result);

    void saveAllRecordInDB(List<MovieModel> movieList, IAsyncResult<List<MovieModel>> result);

    void getMovieByID(final int id, final IAsyncResult<MovieModel> result);

    void getAllMovie(IAsyncResult<List<MovieModel>> result);

    void getMovieSynopsis(int movieId, String lang, IAsyncResult<SynopsisModel> result);

    void getMovieReviews(int movieId, String lang, IAsyncResult<ReviewsModel> result);

    void getMovieCredits(int movieId, IAsyncResult<CreditModel> result);

    void getSimilerMoviesList(int movieId, String lang, IAsyncResult<SimilarModel> result);

}
