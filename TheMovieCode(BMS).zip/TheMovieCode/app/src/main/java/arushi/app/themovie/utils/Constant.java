package arushi.app.themovie.utils;

public class Constant {
    public static final String EXTRA_MOVIE_ID= "extra_movie_id";
    public static final String EXTRA_LANG= "extra_lang";
    public static final String DEFAULT_LANG= "en-US";

}
