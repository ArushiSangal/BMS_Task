package arushi.app.themovie.callback;

public interface IAsyncResult<TModel> {

    void success(TModel tModel);

    void fail(String error);
}
