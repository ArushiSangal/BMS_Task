package arushi.app.themovie.views.ui;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import arushi.app.themovie.R;

import arushi.app.themovie.callback.IAsyncResult;
import arushi.app.themovie.model.CreditModel;
import arushi.app.themovie.model.MovieModel;
import arushi.app.themovie.model.ReviewsModel;
import arushi.app.themovie.model.SimilarModel;
import arushi.app.themovie.model.SynopsisModel;
import arushi.app.themovie.service.impl.MoviesService;
import arushi.app.themovie.service.interfaces.IMoviesService;
import arushi.app.themovie.utils.Constant;
import arushi.app.themovie.views.adapter.ReviewsAdapter;

import com.squareup.picasso.Picasso;

public class MovieDetailActivity extends Activity implements View.OnClickListener {
    private final String TAG = MovieDetailActivity.class.getSimpleName();
    private MovieModel mMovieModel;
    private ImageView ivBack;
    private IMoviesService mMovieService;
    private TextView tvOverView, tvTitle, tvReleaseDate, tvOriginalLanguage, tvTagline, tvNoReview;
    private ImageView ivMoviePoster;
    private int mMovieId;
    private SynopsisModel mSynopsisModel;
    private CreditModel mCreditModel;
    private ReviewsModel mReviewsModel;
    private SimilarModel mSimilarModel;
    private RecyclerView mRecyclerView;
    private String language;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        this.init();
        this.handleListener();
        this.getMovieFromLocal();
    }

    private void handleListener() {
        ivBack.setOnClickListener(this);
    }

    private void getMovieFromLocal() {
       /* mMovieService.getMovieByID(mMovieId, new IAsyncResult<MovieModel>() {
            @Override
            public void success(MovieModel movieModel) {
                if (null == movieModel) {
                    Log.e(TAG, "model is null");
                    return;
                }
                mMovieModel = movieModel;
            }

            @Override
            public void fail(String error) {
                Log.e(TAG, "wrong id, movie not exist by this id" + error);
            }
        });*/

        mMovieService.getMovieSynopsis(mMovieId, language, new IAsyncResult<SynopsisModel>() {
            @Override
            public void success(SynopsisModel synopsisModel) {
                if (null == synopsisModel) {
                    Log.i(TAG, "synopsisModel is null");
                    return;
                }
                mSynopsisModel = synopsisModel;
                setData();
                getSynopsisData();
            }

            @Override
            public void fail(String error) {
                Log.e(TAG, "getMovieSynopsis- failed. Reason -" + error);
            }
        });

        mMovieService.getMovieReviews(mMovieId, language, new IAsyncResult<ReviewsModel>() {
            @Override
            public void success(ReviewsModel reviewsModel) {
                if (null == reviewsModel) {
                    Log.i(TAG, "reviewsModel is null");
                    return;
                }
                mReviewsModel = reviewsModel;
                setReviewsData();
            }

            @Override
            public void fail(String error) {
                Log.e(TAG, "getMovieReviews- failed. Reason -" + error);
            }
        });

        mMovieService.getMovieCredits(mMovieId, new IAsyncResult<CreditModel>() {
            @Override
            public void success(CreditModel creditModel) {
                if (null == creditModel) {
                    Log.i(TAG, "creditModel is null");
                    return;
                }
                mCreditModel = creditModel;
            }

            @Override
            public void fail(String error) {
                Log.e(TAG, "getMovieCredits- failed. Reason -" + error);
            }
        });

        mMovieService.getSimilerMoviesList(mMovieId, language, new IAsyncResult<SimilarModel>() {
            @Override
            public void success(SimilarModel similarModel) {
                if (null == similarModel) {
                    Log.i(TAG, "similarModel is null");
                    return;
                }
                mSimilarModel = similarModel;
            }

            @Override
            public void fail(String error) {
                Log.e(TAG, "getSimilerMoviesList- failed. Reason -" + error);
            }
        });
    }

    private void setReviewsData() {
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, true);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        ReviewsAdapter reviewAdapter = new ReviewsAdapter(mReviewsModel.getResults());
        if (null != mReviewsModel.getResults() && mReviewsModel.getResults().size() > 0) {
            mRecyclerView.setAdapter(reviewAdapter);
            mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);

                }
            });
        } else {
            mRecyclerView.setVisibility(View.GONE);
            tvNoReview.setVisibility(View.VISIBLE);
        }
    }

    private void getSynopsisData() {
        tvTagline.setText(mSynopsisModel.getTagline());
        tvOriginalLanguage.setText(mSynopsisModel.getOriginal_language());
    }

    private void setData() {
        String imagePosterPath = "https://image.tmdb.org/t/p/w500" + mSynopsisModel.getPoster_path();
        Picasso.with(this).load(imagePosterPath).into(ivMoviePoster);
        tvTitle.setText(mSynopsisModel.getTitle());
        tvReleaseDate.setText(mSynopsisModel.getRelease_date());
        tvOverView.setText(mSynopsisModel.getOverview());
    }

    private void init() {
        mMovieService = new MoviesService();
        ivBack = findViewById(R.id.iv_back);
        ivMoviePoster = findViewById(R.id.iv_movie_poster);
        tvTitle = findViewById(R.id.tv_title);
        tvOriginalLanguage = findViewById(R.id.tv_original_language);
        tvOverView = findViewById(R.id.tv_overview);
        tvReleaseDate = findViewById(R.id.tv_release_date);
        tvTagline = findViewById(R.id.tv_tagline);
        tvNoReview = findViewById(R.id.tv_no_review);
        mRecyclerView = findViewById(R.id.recycler_view_review);
        mMovieId = getIntent().getIntExtra(Constant.EXTRA_MOVIE_ID, 0);
        language = getIntent().getStringExtra(Constant.EXTRA_LANG);

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.iv_back) {
            finish();
        }

    }
}