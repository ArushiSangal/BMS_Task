package arushi.app.themovie.database;

public class DbUtils {

    public static final String DB_NAME = "the_movie.db";
    public static final String TABLE_MOVIE = "movie";

}
