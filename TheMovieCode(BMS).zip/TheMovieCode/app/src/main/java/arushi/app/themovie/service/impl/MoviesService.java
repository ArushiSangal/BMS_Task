package arushi.app.themovie.service.impl;


import arushi.app.themovie.callback.IAsyncResult;
import arushi.app.themovie.model.CreditModel;
import arushi.app.themovie.model.ListMoviesModel;
import arushi.app.themovie.model.MovieModel;
import arushi.app.themovie.model.ReviewsModel;
import arushi.app.themovie.model.SimilarModel;
import arushi.app.themovie.model.SynopsisModel;
import arushi.app.themovie.repository.impl.MovieRepository;
import arushi.app.themovie.repository.interfaces.IMovieRepository;
import arushi.app.themovie.service.interfaces.IMoviesService;

import java.util.List;

public class MoviesService implements IMoviesService {
    private IMovieRepository movieRepository;

    public MoviesService() {
        movieRepository = new MovieRepository();
    }

    @Override
    public void getMoviesList(int page, String lang, final IAsyncResult<ListMoviesModel> result) {
        movieRepository.getMovieList(page, lang, result);
    }

    @Override
    public void saveAllRecordInDB(List<MovieModel> movieList, IAsyncResult<List<MovieModel>> result) {
        movieRepository.saveAllRecordInDB(movieList, result);
    }

    @Override
    public void getMovieByID(int id, IAsyncResult<MovieModel> result) {
        movieRepository.getMovieByID(id, result);
    }

    @Override
    public void getAllMovie(IAsyncResult<List<MovieModel>> result) {
        movieRepository.getAllMovie(result);
    }

    @Override
    public void getMovieSynopsis(int movieId, String lang, IAsyncResult<SynopsisModel> result) {
        movieRepository.getMovieSynopsis(movieId, lang, result);
    }

    @Override
    public void getMovieReviews(int movieId, String lang, IAsyncResult<ReviewsModel> result) {
        movieRepository.getMovieReviews(movieId, lang, result);
    }

    @Override
    public void getMovieCredits(int movieId, IAsyncResult<CreditModel> result) {
        movieRepository.getMovieCredits(movieId, result);
    }

    @Override
    public void getSimilerMoviesList(int movieId, String lang, IAsyncResult<SimilarModel> result) {
        movieRepository.getSimilerMoviesList(movieId, lang, result);
    }
}
