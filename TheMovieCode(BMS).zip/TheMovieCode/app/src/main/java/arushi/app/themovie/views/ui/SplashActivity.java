package arushi.app.themovie.views.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import arushi.app.themovie.R;
import com.squareup.picasso.Picasso;

public class SplashActivity extends Activity {

    private static final long TIME_IN_MILLIS = 3000;  //3 sec
    private ImageView ivLogo;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitvity_splash);
       /* ivLogo= findViewById(R.id.iv_logo);
        //path fetched from website
        String logoUrl= "https://www.themoviedb.org/assets/2/v4/logos/v2/blue_square_2-d537fb228cf3ded904ef09b136fe3fec72548ebc1fea3fbbd1ad9e36364db38b.svg";
        Picasso.with(this).load(logoUrl).into(ivLogo);*/
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(SplashActivity.this, MoviesActivity.class));
                finish();
            }
        }, TIME_IN_MILLIS);
    }
}
