package arushi.app.themovie.views.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import arushi.app.themovie.R;
import arushi.app.themovie.model.ReviewContentModel;

public class ReviewsAdapter extends RecyclerView.Adapter<ReviewsAdapter.ViewHolder> {

    private List<ReviewContentModel> mReviewsModelList;

    public ReviewsAdapter(List<ReviewContentModel> mReviewsModelList) {
        this.mReviewsModelList = mReviewsModelList;
    }

    @NonNull
    @Override
    public ReviewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_reviews, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final ReviewContentModel reviewModel = mReviewsModelList.get(position);
        holder.tvTitle.setText(reviewModel.getAuthor());
        holder.tvDescription.setText(reviewModel.getContent());
    }

    @Override
    public int getItemCount() {
        return mReviewsModelList.size();
    }

    public void updateList(List<ReviewContentModel> reviewContentModels) {
        mReviewsModelList.addAll(reviewContentModels);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDescription;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvDescription = itemView.findViewById(R.id.tv_description);
        }
    }
}
