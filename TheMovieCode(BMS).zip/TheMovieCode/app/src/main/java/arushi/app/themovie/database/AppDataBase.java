package arushi.app.themovie.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import arushi.app.themovie.database.dao.IMovieDao;
import arushi.app.themovie.model.MovieModel;

@Database( entities = {MovieModel.class}, version = 1, exportSchema = false)
public abstract class AppDataBase extends RoomDatabase {

    public abstract IMovieDao getIMovieDao();
}