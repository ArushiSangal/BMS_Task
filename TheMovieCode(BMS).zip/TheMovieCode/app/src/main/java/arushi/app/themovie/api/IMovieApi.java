package arushi.app.themovie.api;

import arushi.app.themovie.model.CreditModel;
import arushi.app.themovie.model.ListMoviesModel;
import arushi.app.themovie.model.ReviewsModel;
import arushi.app.themovie.model.SimilarModel;
import arushi.app.themovie.model.SynopsisModel;
import arushi.app.themovie.utils.Url;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface IMovieApi {

    String API_KEY = "api_key";
    String LANGUAGE = "language";
    String PAGE = "page";
    String MOVIE_ID = "movie_id";

    @GET(Url.GET_MOVIE)
    Call<ListMoviesModel> getMoviesList(@Query(API_KEY) String key, @Query(LANGUAGE) String language, @Query(PAGE) int page);

    @GET(Url.GET_MOVIE_SYNOPSIS)
    Call<SynopsisModel> getMovieSynopsis(@Path(value = MOVIE_ID, encoded = true) int movieID, @Query(API_KEY) String key, @Query(LANGUAGE) String language);

    @GET(Url.GET_MOVIE_REVIEWS)
    Call<ReviewsModel> getMovieReviews(@Path(value = MOVIE_ID, encoded = true) int movieID, @Query(API_KEY) String key, @Query(LANGUAGE) String language, @Query(PAGE) int page);

    @GET(Url.GET_MOVIE_CREDITS)
    Call<CreditModel> getMovieCredit(@Path(value = MOVIE_ID, encoded = true) int movieID, @Query(API_KEY) String key);

    @GET(Url.GET_MOVIE_SIMILAR_MOVIES)
    Call<SimilarModel> getSimilarMovies(@Path(value = MOVIE_ID, encoded = true) int movieID, @Query(API_KEY) String key, @Query(LANGUAGE) String language, @Query(PAGE) int page);

}
