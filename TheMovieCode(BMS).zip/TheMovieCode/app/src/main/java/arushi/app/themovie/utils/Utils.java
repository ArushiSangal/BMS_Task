package arushi.app.themovie.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

public class Utils {

    public static boolean isPrefixOfWord(String sentence,
                                         String searchWord) {
        String[] s = searchWord.toUpperCase().split(" ");
        boolean flag = containsWordsPatternMatch(sentence.toUpperCase(), s);
        System.out.println("Utils.isPrefixOfWord + ======= " + " searching for " + searchWord + " " + sentence + " matches " + flag + " ");
        return flag;
    }

    private static boolean containsWordsPatternMatch(String inputString, String[] words) {

        StringBuilder regexp = new StringBuilder();
        for (String word : words) {
            regexp.append("\\b").append(word).append("[^\\s]|\\b").append(word).append("+");
        }

        Pattern pattern = Pattern.compile(regexp.toString());

        return pattern.matcher(inputString).find();
    }

    public static boolean containsWordsArray(String inputString, String[] words) {
        List<String> inputStringList = Arrays.asList(inputString.split(" "));
        List<String> wordsList = Arrays.asList(words);

        return inputStringList.containsAll(wordsList);
    }
}
