package arushi.app.themovie.utils;

public class Url {

    public static final String BASE_URL = "https://api.themoviedb.org/3/";
    public static final String GET_MOVIE = "movie/now_playing";
    public static final String GET_MOVIE_SYNOPSIS = "movie/{movie_id}";
    public static final String GET_MOVIE_REVIEWS = "movie/{movie_id}/reviews";
    public static final String GET_MOVIE_CREDITS = "movie/{movie_id}/credits";
    public static final String GET_MOVIE_SIMILAR_MOVIES = "movie/{movie_id}/similar";

//    https://api.themoviedb.org/3/movie/now_playing?api_key=<<api_key>>&language=en-US&page=1
}
