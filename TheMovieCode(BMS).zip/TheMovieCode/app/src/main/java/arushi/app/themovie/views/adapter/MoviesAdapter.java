package arushi.app.themovie.views.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import arushi.app.themovie.R;

import arushi.app.themovie.model.MovieModel;
import arushi.app.themovie.utils.Constant;
import arushi.app.themovie.utils.Utils;
import arushi.app.themovie.views.ui.MovieDetailActivity;
import arushi.app.themovie.views.ui.MoviesActivity;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.ViewHolder> {

    private List<MovieModel> mMoviesModelList;

    public MoviesAdapter(List<MovieModel> mMoviesModelList) {
        this.mMoviesModelList = mMoviesModelList;
    }

    @NonNull
    @Override
    public MoviesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_movies, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final MovieModel movieModel = mMoviesModelList.get(position);
        String imagePosterPath = "https://image.tmdb.org/t/p/w500" + movieModel.getPoster_path();
        Picasso.with(holder.itemView.getContext()).load(imagePosterPath).into(holder.ivMoviePoster);
        holder.tvTitle.setText(movieModel.getTitle());
        holder.tvReleaseDate.setText(movieModel.getRelease_date());
        holder.rlMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = holder.rlMain.getContext();
                Intent intent = new Intent(context, MovieDetailActivity.class);
                intent.putExtra(Constant.EXTRA_MOVIE_ID, movieModel.getId());
                ((MoviesActivity) context).onClick(movieModel);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mMoviesModelList.size();
    }

    public void updateList(List<MovieModel> moviesModelList, boolean isFilterResult) {
        if (isFilterResult) {
            mMoviesModelList.clear();
        }
        mMoviesModelList.addAll(moviesModelList);
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivMoviePoster;
        TextView tvTitle, tvReleaseDate;
        RelativeLayout rlMain;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivMoviePoster = itemView.findViewById(R.id.iv_movie_poster);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvReleaseDate = itemView.findViewById(R.id.tv_release_date);
            rlMain = itemView.findViewById(R.id.rl_main);
        }
    }
}
