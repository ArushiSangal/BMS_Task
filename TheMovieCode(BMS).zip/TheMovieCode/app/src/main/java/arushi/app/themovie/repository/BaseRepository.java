package arushi.app.themovie.repository;

public class BaseRepository {

    protected String NETWORK_ERROR;
    protected String LOCAL_DB_ERROR;

    protected BaseRepository() {
        NETWORK_ERROR = "Network Error";
        LOCAL_DB_ERROR = "Local Db Error";
    }
}
