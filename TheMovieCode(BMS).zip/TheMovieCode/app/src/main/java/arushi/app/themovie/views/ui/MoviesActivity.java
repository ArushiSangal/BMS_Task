package arushi.app.themovie.views.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import arushi.app.themovie.R;

import arushi.app.themovie.callback.IAsyncResult;
import arushi.app.themovie.model.ListMoviesModel;
import arushi.app.themovie.model.MovieModel;
import arushi.app.themovie.service.impl.MoviesService;
import arushi.app.themovie.service.interfaces.IMoviesService;
import arushi.app.themovie.utils.Constant;
import arushi.app.themovie.utils.Utils;
import arushi.app.themovie.views.adapter.MoviesAdapter;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MoviesActivity extends Activity implements View.OnClickListener {
    private MoviesAdapter mMoviesAdapter;
    private RecyclerView mRecyclerView;
    private ProgressBar mProgressCircular;
    private IMoviesService mMovieService;
    List<MovieModel> mMovieModelList = new ArrayList<>();
    List<MovieModel> mMovieModelListFull = new ArrayList<>();
    private ImageView ivBack;
    private RelativeLayout rlMain;
    private ListMoviesModel mListMoviesModel;
    private EditText etSearch;
    private LinearLayoutManager mLinearLayoutManager;
    private Button btnSeach;
    private ToggleButton toogleBtnLang;
    private String lang = "en-US";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movies);
        this.init();
        this.handlerListners();
        this.getDataFromServer(1);
    }

    private void handlerListners() {
        btnSeach.setOnClickListener(this);
        toogleBtnLang.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                Locale locale = Locale.ENGLISH;
                if(b){
                    lang = "zh";
                    locale = Locale.SIMPLIFIED_CHINESE;
                }else{

                    lang = "en-US";
                    locale = Locale.ENGLISH;
                }
                //refesh based on language
                getDataFromServer(1);
//                setLocale(locale);
            }
        });
        /*etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                synchronized (this) {
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });*/
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
               /* if (mLinearLayoutManager.findLastCompletelyVisibleItemPosition() == mMovieModelList.size() - 1) {
                    getDataFromServer(mListMoviesModel.getPage() + 1);
                }*/
            }
        });
    }

    private void init() {
        mRecyclerView = findViewById(R.id.recycler_view);
        rlMain = findViewById(R.id.rl_main);
        ivBack = findViewById(R.id.iv_back);
        etSearch = findViewById(R.id.et_search);
        btnSeach = findViewById(R.id.btn_search);
        toogleBtnLang = findViewById(R.id.toogle_btn_lang);
        mProgressCircular = findViewById(R.id.progress_circular);
        mMovieService = new MoviesService();

        ivBack.setVisibility(View.GONE);
        this.initList(mMovieModelList);
    }

    private void initList(List<MovieModel> movieModelList) {
        mLinearLayoutManager = new LinearLayoutManager(getApplicationContext());
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        mMoviesAdapter = new MoviesAdapter(movieModelList);
        mRecyclerView.setAdapter(mMoviesAdapter);
    }

    private void getDataFromServer(int page) {
        mProgressCircular.setVisibility(View.VISIBLE);
        mMovieService.getMoviesList(page, lang, new IAsyncResult<ListMoviesModel>() {
            @Override
            public void success(ListMoviesModel dataModelList) {
                mListMoviesModel = dataModelList;
                showData(dataModelList.getResults());
            }

            @Override
            public void fail(String error) {
                mProgressCircular.setVisibility(View.GONE);
                Snackbar.make(rlMain, error, BaseTransientBottomBar.LENGTH_SHORT).show();
            }
        });
    }

    private void showData(List<MovieModel> movieList) {
        mProgressCircular.setVisibility(View.GONE);
        if (null != mMoviesAdapter) {
            mMovieModelList.addAll(movieList);
            mMovieModelListFull.addAll(movieList);
            mMoviesAdapter.updateList(movieList, true);
        }
    }

    public void onClick(final MovieModel movieModel) {
        Intent intent = new Intent(MoviesActivity.this, MovieDetailActivity.class);
        intent.putExtra(Constant.EXTRA_MOVIE_ID, movieModel.getId());
        intent.putExtra(Constant.EXTRA_LANG, lang);
        startActivity(intent);
    }

    private List<MovieModel> filterList(String searchWord) {
        if (null == mMovieModelListFull) {
            return null;
        }
        List<MovieModel> mMovieModelListFilter = new ArrayList<>();
        for (int index = 0; index < mMovieModelListFull.size(); index++) {
            if (Utils.isPrefixOfWord(mMovieModelListFull.get(index).getTitle(), searchWord)) {
                mMovieModelListFilter.add(mMovieModelListFull.get(index));
            }
        }
        return mMovieModelListFilter;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_search:
                if (etSearch.getText().toString().equals("")) {
                    mMoviesAdapter.updateList(mMovieModelListFull, true);
                    return;
                }
                List<MovieModel> list = filterList(etSearch.getText().toString());
                mMoviesAdapter.updateList(list, true);
                break;
        }
    }

    public void setLocale(Locale locale) {
        Resources res = getApplicationContext().getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = locale;
        res.updateConfiguration(conf, dm);
    }
}
