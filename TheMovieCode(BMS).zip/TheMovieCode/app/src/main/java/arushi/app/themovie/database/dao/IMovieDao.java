package arushi.app.themovie.database.dao;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import arushi.app.themovie.database.DbUtils;
import arushi.app.themovie.model.MovieModel;

import java.util.List;

@Dao
public interface IMovieDao {

    String tableName = DbUtils.TABLE_MOVIE;

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long[] saveAllMoviesDetails(List<MovieModel> trackerModel);

    @Query("SELECT * FROM " + tableName + " where  id= :id")
    MovieModel getMovieByID(int id);

    @Query("SELECT * FROM " + tableName)
    List<MovieModel> getAllMovieRecord();
}
